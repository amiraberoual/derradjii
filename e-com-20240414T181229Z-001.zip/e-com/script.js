 // to Add Active Class to Navbar 

  bars = document.querySelectorAll(".fa-solid fa-bars");
  nav  = document.querySelectorAll(".navbar");
  bars.onclick = function() {
      nav.classList.toggle("active");
  }







